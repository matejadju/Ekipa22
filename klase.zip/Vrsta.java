package si.um.feri.ris.models;

public enum Vrsta {
    lastnik,
    organizator,
    korisnik

}
